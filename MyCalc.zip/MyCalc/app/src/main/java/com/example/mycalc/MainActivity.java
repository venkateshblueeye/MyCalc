package com.example.mycalc;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button add, sub, mul, div;
    EditText val1, val2;
    TextView resl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Link UI components
        add = findViewById(R.id.buttonAdd);
        sub = findViewById(R.id.buttonsub);
        mul = findViewById(R.id.buttonmul);
        div = findViewById(R.id.buttondiv);

        val1 = findViewById(R.id.txtvalue1);
        val2 = findViewById(R.id.txtvalue2);
        resl = findViewById(R.id.Rbox);

        // Set listeners
        add.setOnClickListener(this);
        sub.setOnClickListener(this);
        mul.setOnClickListener(this);
        div.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        float Num1;
        float Num2;
        float Result = 0;
        String oper = "";

        // Check empty fields
        if (TextUtils.isEmpty(val1.getText().toString().trim()) ||
                TextUtils.isEmpty(val2.getText().toString().trim())) {
            resl.setText("Enter both values");
            return;
        }

        // Read values safely
        try {
            Num1 = Float.parseFloat(val1.getText().toString().trim());
            Num2 = Float.parseFloat(val2.getText().toString().trim());
        } catch (NumberFormatException e) {
            resl.setText("Invalid input");
            return;
        }

        // Perform operation
        int id = v.getId();
        if (id == R.id.buttonAdd) {
            oper = "+";
            Result = Num1 + Num2;
        } else if (id == R.id.buttonsub) {
            oper = "-";
            Result = Num1 - Num2;
        } else if (id == R.id.buttonmul) {
            oper = "*";
            Result = Num1 * Num2;
        } else if (id == R.id.buttondiv) {
            oper = "/";
            if (Num2 == 0) {
                resl.setText("Cannot divide by zero");
                return;
            }
            Result = Num1 / Num2;
        }

        // Show result
        resl.setText(Num1 + " " + oper + " " + Num2 + " = " + Result);
    }
}
